<?php
return [
  'activity_log'=>'Activity Log|Activity Logs'
];