<?php

return [
    'name' => 'ActivityLog'
];
