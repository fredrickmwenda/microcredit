<?php

return [
    ['name' => 'Activity Logs', 'is_parent' => 1, 'module' => 'Activitylog', 'slug' => 'activity_log', 'parent_slug' => '', 'url' => 'activity_log', 'icon' => 'fa fa-database', 'order' => 60, 'permissions' => 'activitylog.activity_logs.index'],
];