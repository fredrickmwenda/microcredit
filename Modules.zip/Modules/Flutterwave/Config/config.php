<?php

return [
    'name' => 'Flutterwave'
];
