<?php
/**
 * Created by PhpStorm.
 * User: tj
 * Date: 8/2/19
 * Time: 7:55 PM
 */
return [
    'dashboard' => 'Dashboard|Dashboards',
    'widget' => 'Widget|Widgets',
    'successfully_rearranged'=>'Successfully rearranged dashboard',
    'failed_rearrange'=>'Failed to rearrange dashboard',
    'drag_widget_here_to_delete'=>'Drag Widget Here To Delete It',
];