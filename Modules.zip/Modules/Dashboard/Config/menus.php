<?php

return [
    ['name' => 'Dashboard', 'is_parent' => 1, 'module' => 'Dashboard', 'slug' => 'dashboard', 'parent_slug' => '', 'url' => 'dashboard', 'icon' => 'fas fa-home', 'order' => 0, 'permissions' => 'dashboard.index'],
];