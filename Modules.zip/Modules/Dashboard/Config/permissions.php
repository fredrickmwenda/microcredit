<?php

return [
    ['name' => 'dashboard.index', 'display_name' => 'View Dashboard', 'module' => 'Dashboard'],
    ['name' => 'dashboard.edit', 'display_name' => 'Edit Dashboard', 'module' => 'Dashboard'],
];