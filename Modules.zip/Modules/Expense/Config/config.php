<?php

return [
    'name' => 'Expense'
];
