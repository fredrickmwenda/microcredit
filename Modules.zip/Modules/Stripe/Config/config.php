<?php

return [
    'name' => 'Stripe'
];
