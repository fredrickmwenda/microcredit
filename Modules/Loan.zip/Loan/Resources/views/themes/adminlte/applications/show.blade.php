@extends('core::layouts.master')
@section('title')
    {{ trans_choice('loan::general.loan_application',1) }} {{ $application->reference_number }}
@endsection
@section('content')
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>
                        {{ trans_choice('loan::general.loan_application',1) }}
                        <a href="#" onclick="window.history.back()"
                           class="btn btn-outline-light bg-white d-none d-sm-inline-flex">
                            <em class="icon ni ni-arrow-left"></em><span>{{ trans_choice('core::general.back',1) }}</span>
                        </a>
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{url('dashboard')}}">{{ trans_choice('dashboard::general.dashboard',1) }}</a></li>
                        <li class="breadcrumb-item"><a href="{{url('loan/application')}}">{{ trans_choice('loan::general.loan_application',2) }}</a></li>
                        <li class="breadcrumb-item active">{{ $application->reference_number }}</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content" id="app">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-bordered card-preview">
                    <div class="card-header">
                        <h5 class="card-title">{{ $application->full_name }} ({{ $application->reference_number }})</h5>
                        <div class="card-tools">
                            <div class="float-right btn-group">
                                @if($application->level1_status === 'Pending')
                                    <a href="#" data-toggle="modal" data-target="#level1_review_modal" class="btn btn-primary">
                                        <i class="ri-user-star-line"></i> {{ trans_choice('loan::general.level1_review',1) }}
                                    </a>
                                    <a href="#" data-toggle="modal" data-target="#reject_modal" class="btn btn-danger">
                                        <i class="ri-close-circle-line"></i> {{ trans_choice('core::general.reject',1) }}
                                    </a>
                                @endif
                                @if($application->level1_status === 'Approved' && $application->level2_status === 'Pending')
                                    <a href="#" data-toggle="modal" data-target="#level2_approve_modal" class="btn btn-success">
                                        <i class="ri-shield-user-line"></i> {{ trans_choice('loan::general.level2_approve',1) }}
                                    </a>
                                    <a href="#" data-toggle="modal" data-target="#reject_modal" class="btn btn-danger">
                                        <i class="ri-close-circle-line"></i> {{ trans_choice('core::general.reject',1) }}
                                    </a>
                                    <a href="#" data-toggle="modal" data-target="#defer_modal" class="btn btn-warning">
                                        <i class="ri-time-line"></i> {{ trans_choice('core::general.defer',1) }}
                                    </a>
                                @endif
                                @if($application->overall_status === 'Converted' && $application->level2_status === 'Approved')
                                     <?php
                                        $loan = \Modules\Loan\Entities\Loan::where('loan_pre_application_id', $application->id)->first();
                                        $clientId = $loan ? $loan->client_id : null;
                                    ?>
                                    @if($clientId)
                                    <a href="{{url('client/'.$clientId.'/show')}}" class="btn btn-info">
                                        <i class="ri-user-line"></i> {{ trans_choice('client::general.view_client',1) }}
                                    </a>
                                    <a href="{{url('client/'.$clientId.'/credit_score')}}" class="btn btn-success">
                                        <i class="ri-bar-chart-box-line"></i> {{ trans_choice('client::general.credit_score',1) }}
                                    </a>
                                    @endif

                                @endif
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <!-- Level 1 Review Modal -->
                        @if($application->level1_status === 'Pending')
                        <div class="modal fade" id="level1_review_modal">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">{{ trans_choice('loan::general.level1_loan_officer_review',1) }}</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <form method="post" action="{{ url('loan/application/'.$application->id.'/level1') }}"> 
                                        {{csrf_field()}}
                                        <div class="modal-body">
                                            <div class="row gy-4">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="income_stability_score" class="control-label">{{ trans_choice('core::general.income_stability',1) }} (0-100)</label>
                                                        <input type="number" name="income_stability_score" id="income_stability_score" min="0" max="100" class="form-control numeric" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="debt_to_income_score" class="control-label">{{ trans_choice('core::general.debt_to_income',1) }} (0-100)</label>
                                                        <input type="number" name="debt_to_income_score" id="debt_to_income_score" min="0" max="100" class="form-control numeric" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="credit_history_score" class="control-label">{{ trans_choice('core::general.credit_history',1) }} (0-100)</label>
                                                        <input type="number" name="credit_history_score" id="credit_history_score" min="0" max="100" class="form-control numeric" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row gy-4">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="employment_length_score" class="control-label">{{ trans_choice('core::general.employment_length',1) }} (0-100)</label>
                                                        <input type="number" name="employment_length_score" id="employment_length_score" min="0" max="100" class="form-control numeric" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="guarantor_strength_score" class="control-label">{{ trans_choice('core::general.guarantor_strength',1) }} (0-100)</label>
                                                        <input type="number" name="guarantor_strength_score" id="guarantor_strength_score" min="0" max="100" class="form-control numeric" required>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="level1_status" class="control-label">{{ trans_choice('core::general.decision',1) }}</label>
                                                        <select class="form-control" name="level1_status" id="level1_status" required>
                                                            <option value="Approved">{{ trans_choice('core::general.approve',1) }}</option>
                                                            <option value="Declined">{{ trans_choice('core::general.decline',1) }}</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row gy-4">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="recommended_amount" class="control-label">{{ trans_choice('loan::general.recommended_amount',1) }} (GHS)</label>
                                                        <input type="number" step="0.01" name="recommended_amount" id="recommended_amount" class="form-control numeric" required>
                                                    </div>
                                                </div>
                                                <!-- Notes for Level 1 -->
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="level1_notes" class="control-label">{{ trans_choice('loan::general.level1_notes',1) }}</label>
                                                        <textarea class="form-control" name="level1_notes" id="level1_notes" rows="3"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default float-left" data-dismiss="modal">
                                                {{ trans_choice('core::general.close',1) }}
                                            </button>
                                            <button type="submit" class="btn btn-primary">{{ trans_choice('core::general.save',1) }}</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        @endif

                        <!-- Level 2 Approve Modal -->
                        @if($application->level1_status === 'Approved' && $application->level2_status === 'Pending')
                        <div class="modal fade" id="level2_approve_modal">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">{{ trans_choice('loan::general.level2_manager_approval',1) }}</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <form method="post" action="{{ url('loan/application/'.$application->id.'/level2') }}">
                                        {{csrf_field()}}
                                        <div class="modal-body">
                                            <div class="alert alert-info">
                                                <p><strong>{{ trans_choice('loan::general.total_score',1) }}:</strong> {{ $application->total_score }}/500</p>
                                                <p><strong>{{ trans_choice('loan::general.risk_rating',1) }}:</strong> {{ $application->risk_rating }}</p>
                                                <p><strong>{{ trans_choice('loan::general.recommended',1) }}:</strong> GHS {{ number_format($application->recommended_amount, 2) }}</p>
                                            </div>
                                            <div class="form-group">
                                                <label for="level2_status" class="control-label">{{ trans_choice('core::general.decision',1) }}</label>
                                                <select class="form-control" name="level2_status" id="level2_status" required>
                                                    <option value="Approved">{{ trans_choice('core::general.approve',1) }}</option>
                                                    <option value="Declined">{{ trans_choice('core::general.decline',1) }}</option>
                                                    <option value="Deferred">{{ trans_choice('core::general.defer',1) }}</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="approved_amount" class="control-label">{{ trans_choice('loan::general.approved_amount',1) }} (GHS)</label>
                                                <input type="number" step="0.01" name="approved_amount" id="approved_amount" class="form-control numeric" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="level2_notes" class="control-label">{{ trans_choice('loan::general.level2_notes',1) }}</label>
                                                <textarea class="form-control" name="level2_notes" id="level2_notes" rows="3"></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default float-left" data-dismiss="modal">
                                                {{ trans_choice('core::general.close',1) }}
                                            </button>
                                            <button type="submit" class="btn btn-primary">{{ trans_choice('core::general.save',1) }}</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="defer_modal">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">{{ trans_choice('core::general.defer',1) }} {{ trans_choice('loan::general.application',1) }}</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <form method="post" action="{{ url('loan/application/'.$application->id.'/level2') }}">
                                        {{csrf_field()}}
                                        <input type="hidden" name="level2_status" value="Deferred">
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label class="control-label">{{ trans_choice('core::general.reason',1) }}</label>
                                                <textarea name="reason" class="form-control" rows="3"></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default float-left" data-dismiss="modal">
                                                {{ trans_choice('core::general.close',1) }}
                                            </button>
                                            <button type="submit" class="btn btn-warning">{{ trans_choice('core::general.defer',1) }}</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        @endif

                        <!-- Reject Modal -->
                        <div class="modal fade" id="reject_modal">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">{{ trans_choice('core::general.reject',1) }} {{ trans_choice('loan::general.application',1) }}</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <form method="post" action="{{ url('loan/application/'.$application->id.'/level1') }}">
                                        {{csrf_field()}}
                                        <input type="hidden" name="level1_status" value="Declined">
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label class="control-label">{{ trans_choice('core::general.reason',1) }}</label>
                                                <textarea name="rejected_notes" class="form-control" rows="3" required></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default float-left" data-dismiss="modal">
                                                {{ trans_choice('core::general.close',1) }}
                                            </button>
                                            <button type="submit" class="btn btn-danger">{{ trans_choice('core::general.reject',1) }}</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="row" style="margin-top: 20px">
                            <div class="col-sm-7 col-md-7 p-10">
                                @if($application->level1_status !== 'Pending')
                                <h4 class="">
                                    {{ trans_choice('loan::general.total_score',1) }}
                                    : <b>{{$application->total_score}}/500</b>
                                </h4>
                                <h4 class="">
                                    {{ trans_choice('loan::general.risk_rating',1) }}
                                    : <b class="@if($application->risk_rating=='High') text-danger @elseif($application->risk_rating=='Medium') text-warning @else text-success @endif">{{$application->risk_rating ?? 'N/A'}}</b>
                                </h4>
                                @if($application->recommended_amount)
                                <h4 class="">
                                    {{ trans_choice('loan::general.recommended_amount',1) }}
                                    : <b>GHS {{number_format($application->recommended_amount,2)}}</b>
                                </h4>
                                @endif
                                @if($application->approved_amount)
                                <h4 class="">
                                    {{ trans_choice('loan::general.approved_amount',1) }}
                                    : <b>GHS {{number_format($application->approved_amount,2)}}</b>
                                </h4>
                                @endif
                                @endif

                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>{{ trans_choice('core::general.criteria',1) }}</th>
                                            <th>{{ trans_choice('loan::general.score',1) }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th>{{ trans_choice('core::general.income_stability',1) }}</th>
                                            <td>{{$application->income_stability_score ?? 0}}</td>
                                        </tr>
                                        <tr>
                                            <th>{{ trans_choice('core::general.debt_to_income',1) }}</th>
                                            <td>{{$application->debt_to_income_score ?? 0}}</td>
                                        </tr>
                                        <tr>
                                            <th>{{ trans_choice('core::general.credit_history',1) }}</th>
                                            <td>{{$application->credit_history_score ?? 0}}</td>
                                        </tr>
                                        <tr>
                                            <th>{{ trans_choice('core::general.employment_length',1) }}</th>
                                            <td>{{$application->employment_length_score ?? 0}}</td>
                                        </tr>
                                        <tr>
                                            <th>{{ trans_choice('core::general.guarantor_strength',1) }}</th>
                                            <td>{{$application->guarantor_strength_score ?? 0}}</td>
                                        </tr>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>{{ trans_choice('loan::general.total',1) }}</th>
                                            <th>{{$application->total_score ?? 0}}</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <div class="col-sm-5 col-md-5">
                                <table class="table table-striped table-bordered">
                                    <tbody>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('core::general.status',1) }}</th>
                                            <td>
                                                <span class="badge badge-{{ $application->overall_status == 'Converted' ? 'success' : ($application->overall_status == 'Declined' ? 'danger' : ($application->overall_status == 'Under Review' ? 'warning' : 'info')) }}">
                                                    {{ $application->overall_status }}
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('loan::general.level1_status',1) }}</th>
                                            <td>
                                                <span class="badge badge-{{ $application->level1_status == 'Approved' ? 'success' : ($application->level1_status == 'Declined' ? 'danger' : 'warning') }}">
                                                    {{ $application->level1_status }}
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('loan::general.level2_review',1) }}</th>
                                            <td>
                                                <span class="badge badge-{{ $application->level2_status == 'Approved' ? 'success' : ($application->level2_status == 'Declined' ? 'danger' : ($application->level2_status == 'Deferred' ? 'info' : 'warning')) }}">
                                                    {{ $application->level2_status }}
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('core::general.name',1) }}</th>
                                            <td>{{$application->first_name}}-{{$application->last_name}}</td>
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('core::general.ghana_card_number',1) }}</th>
                                            <td>{{$application->ghana_card_number}}</td>
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('core::general.phone',1) }}</th>
                                            <td>{{$application->phone_number}}</td>
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('core::general.email',1) }}</th>
                                            <td>{{$application->email}}</td>
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('loan::general.loan_amount_requested',1) }}</th>
                                            <td>GHS {{number_format($application->loan_amount_requested,2)}}</td>
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('loan::general.purpose_of_loan',1) }}</th>
                                            @if($application->purpose_of_loan)
                                                <td>{{ $application->purpose_of_loan }}</td>
                                            @else
                                            <?php
                                                $purpose = \Modules\Loan\Entities\LoanProduct::find($application->loan_product_id);
                                            ?>
                                                <td>{{ $purpose ? $purpose->name : 'N/A' }}</td>
                                            @endif
                                            
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('loan::general.repayment_period',1) }}</th>
                                            <td>{{$application->repayment_period}} {{ trans_choice('loan::general.month',2) }}</td>
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('loan::general.preferred_repayment_method',1) }}</th>
                                            <td>{{$application->preferred_repayment_method}}</td>
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('core::general.employment_status',1) }}</th>
                                            <td>{{$application->employment_status}}</td>
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('core::general.monthly_net_income',1) }}</th>
                                            <td>GHS {{number_format($application->monthly_net_income ?? 0,2)}}</td>
                                        </tr>
                                        <tr>
                                            <th class="table-bold-loan">{{ trans_choice('core::general.submitted_on',1) }}</th>
                                            <td>{{$application->submitted_at?->format('Y-m-d')}}</td>
                                        </tr>
                                        @if($application->level1_decision_at)
                                            <tr>
                                                <th class="table-bold-loan">{{ trans_choice('loan::general.level1_decision_at',1) }}</th>
                                                <td>
                                                    {{ $application->level1_decision_at->format('Y-m-d h:i A') }}
                                                    {{ trans_choice('core::general.by',1) }}
                                                    {{ $application->loanOfficer?->name ?? 'N/A' }}
                                                </td>
                                            </tr>
                                        @endif

                                        @if($application->level2_decision_at)
                                            <tr>
                                                <th class="table-bold-loan">{{ trans_choice('loan::general.level2_decision_at',1) }}</th>
                                                <td>
                                                    {{ $application->level2_decision_at->format('Y-m-d h:i A') }}
                                                    {{ trans_choice('core::general.by',1) }}
                                                    {{ $application->manager?->name ?? 'N/A' }}
                                                </td>
                                            </tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection